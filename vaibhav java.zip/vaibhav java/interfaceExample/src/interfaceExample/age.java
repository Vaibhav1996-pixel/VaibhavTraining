package interfaceExample;

public interface age {
 
	void age1(int a);

}
