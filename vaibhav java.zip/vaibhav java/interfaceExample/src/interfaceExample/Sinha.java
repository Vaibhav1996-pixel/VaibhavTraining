package interfaceExample;

class Sinha implements age {
	
	int age1=23;
	

	public void age1(int a) {
		// TODO Auto-generated method stub
		this.age1=age1;
		System.out.println("my age is : " + age1);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Sinha obj=new Sinha();
     obj.age1(23);
	}
	

}
