package interfaceExample;

abstract class Angel{
	abstract void run();

}
class Abstractclass extends Angel
{
	void run()
	{
		System.out.println("vaibhav is best");
		
	}
	public static void main(String[] args)
{
	Abstractclass Ua = new Abstractclass();
	Ua.run();
}
}

