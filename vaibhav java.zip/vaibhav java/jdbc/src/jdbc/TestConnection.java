package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://127.0.0.1:3306/vaibhav", "root", "root")) 
		{
			
			
			Statement s = conn.createStatement();
			
			
			s.executeUpdate("create table mytable1(firstcoloumn int)");
			s.execute("insert into mytable1 values(1)");
			s.execute("select* from mytable1");
			

            if (conn != null) {
                System.out.println("Connected to the database!");
            } else {
                System.out.println("Failed to make connection!");
            }
            
            
            

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}