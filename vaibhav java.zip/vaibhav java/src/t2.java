
public class t2 {
	public void timethod()
	{
		System.out.println("swati pro");
	}

}
