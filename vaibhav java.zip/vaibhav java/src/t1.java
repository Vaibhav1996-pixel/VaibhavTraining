public class t1 {
	public void timethod()
	{
		System.out.println("t1 method..");
		t2 tn=new t2();
		tn.timethod();
	}

}
