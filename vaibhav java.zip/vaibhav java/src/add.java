
public class add {
	
	  public static void main(String[] args){
		  
		  System.out.println("hello");
		  t1 tt=new t1();
		  t2 t3=new t2():
		  tt.t1method();
	  }

}
