package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LifeCycleServlet
 */
@WebServlet("/LifeCycleServlet")
public class LifeCycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public void init() throws ServletException{   
	super.init();
	System.out.println("Inside init method");
    }
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LifeCycleServlet() {
        System.out.println("creating object of LifeCycleServlet");
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("LifeCycleServlet Get called");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.println("<b>LifeCycle Servlet Get called..");
		out.println("Refresh the page to check lifee cycle method");
    	response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public void destroy() {
		//super.destroy();
		System.out.println("Destroying..");
	}
}
