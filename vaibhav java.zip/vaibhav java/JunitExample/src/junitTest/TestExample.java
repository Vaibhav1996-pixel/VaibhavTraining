package junitTest;

public class TestExample {

	
	
	
	public int ADDInt(int x,int y) {return x+y;}
		
	

		public String ADDString(String s1,String s2) {return s1+s2;}
	}
	
	

