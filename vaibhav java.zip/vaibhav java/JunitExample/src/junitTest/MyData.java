package junitTest;

public class MyData {
	
	public Date(int year, int month, int day)
	public Date()
	public int getDay(), getMonth(), getYear()
	public void addDays(int days)
	

}
