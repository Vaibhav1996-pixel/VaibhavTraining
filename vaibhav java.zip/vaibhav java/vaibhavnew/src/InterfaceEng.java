
public interface InterfaceEng {

  public void vaibhvS(int age);

}

