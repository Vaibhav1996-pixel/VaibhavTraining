package vaibhavnew;

public class Delt {

	private final String name;
	private final Gender gender;
	private final int age;
	
	 public Delt(String n,Gender gn,int a)
	 {
		 name=n;
		 gender=gn;
		 age=a;
		 
		 
	 }
	public String getName()
	{
		return name;
	}
	public Gender getGender()
	{
		return gender;
	}
	public int getAge()
	{
		return age;
	}
	
	public String toString()
	{
	 
	 
	 return String.format("%s  -- %s -- %d",name,gender,age);
	}

}
