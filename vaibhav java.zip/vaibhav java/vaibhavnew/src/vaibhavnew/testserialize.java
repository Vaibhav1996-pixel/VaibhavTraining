package vaibhavnew;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Book implements Serializable{
	private int bookid;
	private String title;
	private String author;
	private transient double price=500.50;
	
	Book(int bookid, String title, String author, double price){
		this.bookid = bookid;
		this.title = title;
		this.author = author;
		this.price = price;
	}
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public String toString() {
		return String.format("Book{ Book Id-%d, Title-%s, Author-%s, Price-%.2f}", bookid, title, author, price);
	}
}
public class testserialize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book1 = new Book(1201, "The complete reference", "Herber Shield", 600);
		try {
			FileOutputStream fos = new FileOutputStream("book.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(book1);
			System.out.println("Book is successfully serialized..");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*//try {
			FileInputStream fis = new FileInputStream("book.ser");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Book b = (Book)ois.readObject();
			System.out.println("Book is successfully deserialized..");
			System.out.println(b);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}
