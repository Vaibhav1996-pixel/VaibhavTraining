package vaibhavnew;

public enum Gender {

	
	MALE,FEMALE;
}
