package vaibhavnew;


import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serializable;

public class Book implements Externalizable{

	private int bookid;
	private String title;
	private String author;
	private  double price=500.50 ;

	public Book() {
		this.author=author;
		this.bookid=bookid;
		this.title=title;
		this.price=price;
		
	}
	public Book(int bid,String t,String a,double p)
	{
		this.bookid=bid;
		this.title=t;
		this.author=a;
		this.price=p;
	}
	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String toString()
	{
		return "Book{ " + "Book id" +"\n" +bookid +"Title" +title+
         	"Author"+author+ "Price"+ price + " }";			
	}
	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		this.author=in.readLine();
		//this.title=(String) in.readObject();
		
	}
	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		// TODO Auto-generated method stub
	out.writeInt(bookid);
	out.writeObject(" ");
	out.writeChars(author);
    out.writeObject(title);
	}
	}
	

package TestSerialize;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class TestExternalizable {
	@SuppressWarnings("unused")
	private String filename="Book.ser";
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub

Book b2=new Book();
Scanner sc=new  Scanner(System.in);
String auth=sc.next();
b2.setAuthor(auth);
b2.setBookid(1111);
b2.setTitle("C++");
Book b3=new Book(100, "java", "Anand", 400);
try {
	//serialize the object
	System.out.println("Before serialization"+ b2);
	FileOutputStream fos=new FileOutputStream("Book.ser");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(b2);
	System.out.println("Book is successfully serialized..");
	//deserialize the book object
	FileInputStream fis=new FileInputStream("Book.ser");
	ObjectInputStream ois=new ObjectInputStream(fis);
	
	b3=(Book) ois.readObject();
	System.out.println("Book is successfully retrieved from serialized object");
	System.out.println("After serialization .."+ b3he);
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		
	}






public class TestExternizable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
