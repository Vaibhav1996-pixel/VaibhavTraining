package vaibhavnew;

public interface InterfaceEng {

}
