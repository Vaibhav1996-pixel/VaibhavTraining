package vaibhavnew;
import java.io.BufferedWriter;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class WriterFileClass{
	 public static void main(String []ar)
	 {
		 try {
			 FileWriter filewriter = new FileWriter("temp.txt");
			 BufferedWriter bufferwriter = new BufferedWriter(filewriter);
			 bufferwriter.write("hello");
			 bufferwriter.write("here is some");
			 bufferwriter.newLine();
			 bufferwriter.write("we are waiting");
			 bufferwriter.write("fuck uhh all");
			 bufferwriter.close();
		 } catch(Exception e) {
			 
			 System.out.println("Error writing");
		 }
	 }
}
