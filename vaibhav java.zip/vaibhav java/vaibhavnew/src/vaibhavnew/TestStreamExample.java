package vaibhavnew;



import java.util.Arrays;
import java.util.List;

public class TestStreamExample {
	
	public static  List<Delt> createDelt(){ 
	
	
	 return  Arrays.asList(
			 
			 new Delt("Rakul",Gender.FEMALE,28),
			 new Delt("vaibhav",Gender.MALE,28),

			 new Delt("akshita",Gender.FEMALE,28),

			 new Delt("vivek",Gender.MALE,45),

			 new Delt("shruti",Gender.FEMALE,67),

			 new Delt("ganesh",Gender.MALE,28),

			 new Delt("guruji",Gender.FEMALE,28)
	);

	 
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Delt> delt=createDelt();
		System.out.println("Printing list before streams..");
		System.out.println(delt);
		System.out.println(
			delt.stream()
			.max((del1,del2) ->
			del1.getAge()>del2.getAge()?1:-1));
			
			
			
	
	}
	
		 
		 











	}


